#!/bin/bash
# ===========================================
# 智能录单系统 - 启动脚本
# ===========================================

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  智能录单系统 - 启动中...${NC}"
echo -e "${GREEN}========================================${NC}"

# 检查 .env 文件是否存在
if [ ! -f ".env" ]; then
    echo -e "${RED}错误: .env 文件不存在！${NC}"
    echo -e "${YELLOW}请复制 .env.example 为 .env 并填写配置：${NC}"
    echo -e "  cp .env.example .env"
    echo -e "  vi .env"
    exit 1
fi

# 检查 node_modules 是否存在
if [ ! -d "node_modules" ]; then
    echo -e "${YELLOW}正在安装依赖...${NC}"
    pnpm install --prod || npm install --production
fi

# 加载环境变量
export $(grep -v '^#' .env | xargs)

# 启动服务
echo -e "${GREEN}启动服务，端口: ${PORT:-5000}${NC}"
node dist/index.js
