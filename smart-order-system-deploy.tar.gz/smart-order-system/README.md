# 智能录单系统 - 部署指南

## 目录结构

```
smart-order-system/
├── client/
│   └── dist/          # 前端静态文件
├── server/
│   ├── dist/          # 后端构建产物
│   ├── package.json   # 生产依赖
│   ├── .env.example   # 环境变量模板
│   └── start.sh       # 启动脚本
└── README.md          # 本文件
```

## 环境要求

- **Node.js**: 24.x 或更高版本
- **pnpm**: 推荐使用（也可用 npm）
- **PostgreSQL**: 14.x 或更高版本

## 第一步：上传部署包

将 `smart-order-system.tar.gz` 上传到服务器，例如 `/www/wwwroot/`

```bash
# 解压
cd /www/wwwroot
tar -xzvf smart-order-system.tar.gz
```

## 第二步：配置环境变量

```bash
cd /www/wwwroot/smart-order-system/server

# 复制环境变量模板
cp .env.example .env

# 编辑配置文件
vi .env
```

**必须配置的环境变量：**

| 变量名 | 说明 | 示例 |
|--------|------|------|
| `DATABASE_URL` | PostgreSQL 连接字符串 | `postgresql://smartorder:password@localhost:5432/smart_order` |
| `COZE_WORKLOAD_IDENTITY_API_KEY` | Coze AI API Key | 从 Coze 平台获取 |
| `PORT` | 服务端口 | `5000` |

## 第三步：安装依赖

```bash
cd /www/wwwroot/smart-order-system/server

# 使用 pnpm（推荐）
pnpm install --prod

# 或使用 npm
npm install --production
```

## 第四步：初始化数据库

确保 PostgreSQL 中已创建数据库，然后执行建表 SQL：

```sql
-- 创建数据库
CREATE DATABASE smart_order;

-- 创建表（如果尚未创建）
-- 表结构由 Drizzle ORM 管理，首次部署需要执行迁移
```

## 第五步：启动服务

### 方式一：直接启动

```bash
cd /www/wwwroot/smart-order-system/server
chmod +x start.sh
./start.sh
```

### 方式二：使用 PM2（推荐生产环境）

```bash
# 安装 PM2
npm install -g pm2

# 启动服务
cd /www/wwwroot/smart-order-system/server
pm2 start dist/index.js --name smart-order-api

# 设置开机自启
pm2 startup
pm2 save
```

### 方式三：使用 systemd（Linux 系统服务）

创建服务文件 `/etc/systemd/system/smart-order.service`：

```ini
[Unit]
Description=Smart Order System API
After=network.target postgresql.service

[Service]
Type=simple
User=www-data
WorkingDirectory=/www/wwwroot/smart-order-system/server
ExecStart=/usr/bin/node dist/index.js
Restart=on-failure
RestartSec=10
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
```

```bash
# 启动服务
systemctl daemon-reload
systemctl start smart-order
systemctl enable smart-order
```

## 第六步：配置 Nginx 反向代理

创建 Nginx 配置文件 `/etc/nginx/sites-available/smart-order.conf`：

```nginx
server {
    listen 80;
    server_name your-domain.com;

    # 前端静态文件
    location / {
        root /www/wwwroot/smart-order-system/client/dist;
        try_files $uri $uri/ /index.html;
        
        # 缓存静态资源
        location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf)$ {
            expires 30d;
            add_header Cache-Control "public, immutable";
        }
    }

    # 后端 API 代理
    location /api/ {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
# 启用配置
ln -s /etc/nginx/sites-available/smart-order.conf /etc/nginx/sites-enabled/
nginx -t
systemctl reload nginx
```

## 验证部署

```bash
# 检查后端服务
curl http://localhost:5000/api/v1/health

# 检查前端
curl http://localhost/

# 查看日志（PM2）
pm2 logs smart-order-api

# 查看日志（systemd）
journalctl -u smart-order -f
```

## 常见问题

### 1. 数据库连接失败
- 检查 `DATABASE_URL` 格式是否正确
- 确认 PostgreSQL 服务正在运行
- 检查数据库用户权限

### 2. AI 功能无法使用
- 确认 `COZE_WORKLOAD_IDENTITY_API_KEY` 配置正确
- 检查服务器能否访问 `api.coze.com`

### 3. 前端页面空白
- 检查 Nginx 配置中 `root` 路径是否正确
- 检查浏览器控制台是否有 API 请求错误

## 更新部署

```bash
# 备份数据库
pg_dump smart_order > backup_$(date +%Y%m%d).sql

# 上传新的部署包并解压覆盖
cd /www/wwwroot
tar -xzvf smart-order-system-new.tar.gz

# 重启服务
pm2 restart smart-order-api
# 或
systemctl restart smart-order
```
